#include <iostream>
using namespace std;

#include "../include/functions.h"

void help() {
    cout << "./main <filename> [-i] [-f (v|h)] [-o (l|r)] [-x <width> <height>] [-e <factor>] " << endl;
}